// Copyright (C) Microsoft Corporation. All rights reserved.
//
// This program is free software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pru_cfg.h>
#include <pru_intc.h>
#include <rsc_types.h>
#include <pru_virtqueue.h>
#include <pru_rpmsg.h>
#include <sys_mailbox.h>
#include "resource_table_1.h"

#include "command.h"
//volatile register uint32_t __R30;
volatile register uint32_t __R31;

/* PRU1 is mailbox module user 2 */
#define MB_USER                                         2
/* Mbox0 - mail_u2_irq (mailbox interrupt for PRU1) is Int Number 59 */
#define MB_INT_NUMBER                           59

/* Host-1 Interrupt sets bit 31 in register R31 */
#define HOST_INT                                        0x80000000

/* The mailboxes used for RPMsg are defined in the Linux device tree
 * PRU0 uses mailboxes 2 (From ARM) and 3 (To ARM)
 * PRU1 uses mailboxes 4 (From ARM) and 5 (To ARM)
 */
#define MB_TO_ARM_HOST                          5
#define MB_FROM_ARM_HOST                        4

/*
 * Using the name 'rpmsg-pru' will probe the rpmsg_pru driver found
 * at linux-x.y.z/drivers/rpmsg/rpmsg_pru.c
 */
#define CHAN_NAME                                       "rpmsg-pru"
#define CHAN_DESC                                       "Channel 31"
#define CHAN_PORT                                       31

/*
 * Used to make sure the Linux drivers are ready for RPMsg communication
 * Found at linux-x.y.z/include/uapi/linux/virtio_config.h
 */
#define VIRTIO_CONFIG_S_DRIVER_OK       4

uint8_t addr[13] = { 0x12, 0x16, 0x17, 0x18, 0x1C, 0x1D, 0x1E, 0x13, 0x14, 0x15, 0x19, 0x1A, 0x1B };

/*
 * main.c
 */
void main() {
        struct pru_rpmsg_transport transport;
        uint16_t src, dst, len;
        volatile uint8_t *status;
        
        request_t request;
        response_t response;
        uint8_t i, x, a;
        uint16_t y;

        /* allow OCP master port access by the PRU so the PRU can read external memories */
        CT_CFG.SYSCFG_bit.STANDBY_INIT = 0;
        
        /* clear the status of event MB_INT_NUMBER (the mailbox event) and enable the mailbox event */
        CT_INTC.SICR_bit.STATUS_CLR_INDEX = MB_INT_NUMBER;
        CT_MBX.IRQ[MB_USER].ENABLE_SET |= 1 << (MB_FROM_ARM_HOST * 2);

        /* Make sure the Linux drivers are ready for RPMsg communication */
        status = &resourceTable.rpmsg_vdev.status;
        while (!(*status & VIRTIO_CONFIG_S_DRIVER_OK));

        /* Initialize pru_virtqueue corresponding to vring0 (PRU to ARM Host direction) */
        pru_virtqueue_init(&transport.virtqueue0, &resourceTable.rpmsg_vring0, &CT_MBX.MESSAGE[MB_TO_ARM_HOST], &CT_MBX.MESSAGE[MB_FROM_ARM_HOST]);

        /* Initialize pru_virtqueue corresponding to vring1 (ARM Host to PRU direction) */
        pru_virtqueue_init(&transport.virtqueue1, &resourceTable.rpmsg_vring1, &CT_MBX.MESSAGE[MB_TO_ARM_HOST], &CT_MBX.MESSAGE[MB_FROM_ARM_HOST]);

        /* Create the RPMsg channel between the PRU and ARM user space using the transport structure. */
        while(pru_rpmsg_channel(RPMSG_NS_CREATE, &transport, CHAN_NAME, CHAN_DESC, CHAN_PORT) != PRU_RPMSG_SUCCESS);
        while(1){
                /* Check bit 31 of register R31 to see if the mailbox interrupt has occurred */
                if(__R31 & HOST_INT){
                        /* Clear the mailbox interrupt */
                        CT_MBX.IRQ[MB_USER].STATUS_CLR |= 1 << (MB_FROM_ARM_HOST * 2);
                        /* Clear the event status, event MB_INT_NUMBER corresponds to the mailbox interrupt */
                        CT_INTC.SICR_bit.STATUS_CLR_INDEX = MB_INT_NUMBER;
                        /* Use a while loop to read all of the current messages in the mailbox */
                        while(CT_MBX.MSGSTATUS_bit[MB_FROM_ARM_HOST].NBOFMSG > 0){
                                /* Check to see if the message corresponds to a receive event for the PRU */
                                if(CT_MBX.MESSAGE[MB_FROM_ARM_HOST] == 1){
                                        /* Receive the message */
                                        if(pru_rpmsg_receive(&transport, &src, &dst, &request, &len) == PRU_RPMSG_SUCCESS){
											
                                                response.cmd = request.cmd;
												response.seq = request.seq;
												
                                                switch(response.cmd)
                                                {
													case GET_THROTTLE_LIMIT:	//CMD:01h
														response.data[0] = *(SHAREDATA + 0x25);
														response.data[1] = (*(SHAREDATA + 0x25)) >> 8;
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 4;
														break;
													
													case SET_THROTTLE_LIMIT:	//CMD:02h
														*(volatile uint16_t *)(SHAREDATA + 0x25) = request.data[0] | (request.data[1] << 8);
														response.status = (*(SHAREDATA + 0x25) != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 4;
														break;
														
													case GET_PWR_READING:	//CMD:03h	
														response.data[0] = *(SHAREDATA + 0x23);
														response.data[1] = (*(SHAREDATA + 0x23)) >> 8;
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 4;
														break;
																						
													case GET_PHASE_PWR_READING:	//CMD:04h
														x = (request.data[0] == 0) ? 0 : 3;
														a = 0;
														for(i = x; i < x + 3 ; i++)
														{
															response.data[a] = *(SHAREDATA + 12 + i);
															response.data[a + 1] = (*(SHAREDATA + 12 + i)) >> 8;
															a += 2;
														}
												
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 8;
														
														break;
													
													case GET_PHASE_I_READING:	//CMD: 05h
														response.data[0] = request.data[0];
														response.data[1] = RESERVED;
														
														x = (request.data[0] == 0) ? 0 : 6;
														a = 2;
														for(i = x; i < x + 3 ; i++)
														{
															response.data[a] = *(SHAREDATA + 3 + i);
															response.data[a + 1] = (*(SHAREDATA + 3 + i)) >> 8;
															a += 2;
														}
												
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 10;
														
														break;
														
													case GET_PHASE_V_READING:	//CMD:06h
														response.data[0] = request.data[0];
														response.data[1] = RESERVED;
														
														x = (request.data[0] == 0) ? 0 : 6;
														
														a = 2;
														for(i = x; i < x + 3 ; i++)
														{
															response.data[a] = *(SHAREDATA + i);
															response.data[a + 1] = (*(SHAREDATA + i)) >> 8;
															a += 2;
														}
												
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 10;														
														break;
													
													case SET_THROTTLE:	//CMD:07h
														*(volatile uint16_t *)(SHAREDATA + 0x26) = request.data[0];
														*(volatile uint16_t *)(SHAREDATA + 0x44) = request.data[1];
														len = 4;
														break;
														
													case GET_THROTTLE:	//CMD:08h
														response.data[0] = *(SHAREDATA + 0x26);
														response.data[1] = *(SHAREDATA + 0x21);
														response.data[2] = *(SHAREDATA + 0x44);
														response.data[3] = *(SHAREDATA + 0x45);														
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 6;
														break;
														
													case CONTROL_THROTTLE:	//CMD:09h
														*(volatile uint16_t *)(SHAREDATA + 0x27) = request.data[0];
														response.data[0] = *(SHAREDATA + 0x43);
														*(volatile uint16_t *)(SHAREDATA + 0x46) = 1;
														break;
													
													case SET_OFFSET:	//CMD:0Ah
														//x = ((request.data[1] & 0x03) == 1) ? 0x5C : 0x74;
														//y = SHAREADDR + x + ((request.data[0] - 1)*2);
														//*(volatile uint16_t *) (y) = request.data[2] | (request.data[3] << 8);
														//response.status = STATUS_SUCCESS;
														
														if((request.data[1] & 0x03) == 1)
														{
															switch(request.data[0])
															{
																case 1:
																	*(volatile uint16_t *) (0x01005C) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 2:
																	*(volatile uint16_t *) (0x01005E) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 3:
																	*(volatile uint16_t *) (0x010060) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 4:
																	*(volatile uint16_t *) (0x010062) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 5:
																	*(volatile uint16_t *) (0x010064) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 6:
																	*(volatile uint16_t *) (0x010066) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																default:
																	response.status = STATUS_INVALID_CMD;
																break;
															}
														}
														else if((request.data[1] & 0x03) == 0)
														{
															switch(request.data[0])
															{
																case 1:
																	*(volatile uint16_t *) (0x010074) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 2:
																	*(volatile uint16_t *) (0x010076) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 3:
																	*(volatile uint16_t *) (0x010078) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 4:
																	*(volatile uint16_t *) (0x01007A) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 5:
																	*(volatile uint16_t *) (0x01007C) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 6:
																	*(volatile uint16_t *) (0x01007E) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																default:
																	response.status = STATUS_INVALID_CMD;
																break;
															}
														}
														else 
														{
															response.status = STATUS_INVALID_CMD;
														}
														
														len = 4;
														break;
													
													case GET_OFFSET:	//CMD:0Bh
														x = (request.data[1] == 1) ? 0x2E : 0x3A;
														response.data[0] = request.data[0];
														response.data[1] = request.data[1];
														response.data[2] = *(SHAREDATA + x + (request.data[0] - 1));
														response.data[3] = *(SHAREDATA + x + (request.data[0] - 1)) >> 8;
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 6;
														break;
														
													case SET_GAIN:		//CMD:0Ch
														//x = (request.data[1] == 1) ? 0x50 : 0x68;
														//*(volatile uint16_t *) (SHAREDATA + x + ((request.data[0] - 1)*2)) = request.data[2] | (request.data[3] << 8);
														//response.status = STATUS_SUCCESS;
														if((request.data[1] & 0x03) == 1)
														{
															switch(request.data[0])
															{
																case 1:
																	*(volatile uint16_t *) (0x010050) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																
																case 2:
																	*(volatile uint16_t *) (0x010052) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																
																case 3:
																	*(volatile uint16_t *) (0x010054) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																
																case 4:
																	*(volatile uint16_t *) (0x010056) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 5:
																	*(volatile uint16_t *) (0x010058) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																
																case 6:
																	*(volatile uint16_t *) (0x01005A) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																
																default:
																	response.status = STATUS_INVALID_CMD;
																break;
															}
														}
														else if((request.data[1] & 0x03) == 0)
														{
															switch(request.data[0])
															{
																case 1:
																	*(volatile uint16_t *) (0x010068) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 2:
																	*(volatile uint16_t *) (0x01006A) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 3:
																	*(volatile uint16_t *) (0x01006C) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 4:
																	*(volatile uint16_t *) (0x01006E) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 5:
																	*(volatile uint16_t *) (0x010070) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																case 6:
																	*(volatile uint16_t *) (0x010072) = request.data[2] | (request.data[3] << 8);
																	response.status = STATUS_SUCCESS;
																break;
																default:
																	response.status = STATUS_INVALID_CMD;
																break;
															}
														}
														else 
														{
															response.status = STATUS_INVALID_CMD;
														}
														len = 4;
														break;
														
													case GET_GAIN:	//CMD:0Dh
														x = (request.data[1] == 1) ? 0x28 : 0x34;
														response.data[0] = request.data[0];
														response.data[1] = request.data[1];
														response.data[2] = *(SHAREDATA + x + (request.data[0] - 1));
														response.data[3] = *(SHAREDATA + x + (request.data[0] - 1)) >> 8;
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														
														len = 6;
														break;
													
													case PHASE_STATUS:	//CMD:20h
														x = (request.data[0] == 0) ? 0x1F : 0x20;
														response.data[0] = *(SHAREDATA + x);
														response.data[1] = *(SHAREDATA + x) >> 8;
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 4;
														break;
													
													case MAX_PWR_STAT:	//CMD:21h
														for(i = 0; i < 26; i+=2)
														{
															response.data[i] = *(SHAREDATA + addr[i / 2]);
															response.data[i + 1] = *(SHAREDATA + addr[i / 2]) >> 8;
														}
														
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 28;
														break;
													
													case CLEAR_MAX_PWR_STAT:	//CMD:22h
														*(volatile uint16_t *) (SHAREDATA + 0x40) = 1;
														response.status = STATUS_SUCCESS;
														len = 4;
														break;
														
													case CLEAR_STATUS:	//CMD:23h
														*(volatile uint16_t *) (SHAREDATA + 0x41 + request.data[0]) = 1;
														response.status = STATUS_SUCCESS;
														len = 4;
														break;
													
													case FIRMWARE_VERSION:	//CMD:30h
														response.data[0] = *(SHAREDATA + 0x22);
														response.data[1] = (*(SHAREDATA + 0x22)) >> 8;
														response.status = (response.data != NULL) ? STATUS_SUCCESS : STATUS_RESOURCE;
														len = 4;
														break;
														
													default:
														response.status = STATUS_INVALID_CMD;
													break;
												}
                                                pru_rpmsg_send(&transport, dst, src, &response, len);
                                        }
                                }
                        }
                }
        }
}

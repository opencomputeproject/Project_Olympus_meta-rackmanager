// Copyright (C) Microsoft Corporation. All rights reserved.
//
// This program is free software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.



#ifndef PRU_RPMSG_INTERRUPT0_DUMMY_MAIN_POWER_H_
#define PRU_RPMSG_INTERRUPT0_DUMMY_MAIN_POWER_H_

//--- Common definitions ---//
#define TRUE 1
#define FALSE 0

//--- ADC definitions ---//
#define middleSenseV    16383
#define ADCset 6U
#define ADC1Fifodata	((volatile uint32_t *)(        0x4834C100       ))//0x44E0D100
#define timeIntegral     72	    // for 60ms  2^18 / 2400 * 1.1107 = 121.31
                                // for 100ms 2^18 / 4000 * 1.1107 = 72
								// for 200ms 2^18 / 8000 * 1.1107 = 36

#define SAMPLE_CST		 4000   // for 60ms  / 25us = 2400
								// for 100ms / 25us = 4000
								// for 200ms / 25us = 8000

#define iacBase	70.7//(61)
#define vacBase 431//(for 60ms)//1320(EVT1)//1266(preEVT)//(1209) //518(495)=

//--- Timer definitions ---
#define timeBase40k					40000
#define timeLoop1s(dataIn)			(int)((float)dataIn*timeBase40k)


//--- Protect Point ---//
#define OCLEVEL 	inputIQ14(24)
#define UVLEVEL		inputVQ14(190)
#define OVLEVEL 	inputVQ14(250)
#define HIGHLIMITTIME		timeLoop1s(0.05)
#define HIGHRECOVERTIME		timeLoop1s(0.5)


#define inputVQ14(DateIn)   			(unsigned int)((long)DateIn*FormatQ14/vacBase)
#define inputIQ14(DateIn)   			(unsigned int)((long)DateIn*FormatQ14/iacBase)
#define FormatQ14	16384

//#define  timeBase10ms     100  //(1/10ms)=100
//#define  timeLoop10ms(dataIn)   dataIn*timeBase10ms //=> 0.5*100 = 50 => 50*10ms =500ms

//--- Struct Area ---//
typedef union
{
	unsigned char all;
	struct
	{
		unsigned char	enableCalMaxAvg				:1;		//0
		unsigned char	rsvd1						:1;		//1
		unsigned char	rsvd2						:1;		//2
		unsigned char	rsvd3						:1;		//3
		unsigned char	rsvd4						:1;		//4
		unsigned char 	rsvd5						:1;		//5
		unsigned char	rsvd6						:1;		//6
		unsigned char 	rsvd7						:1;		//7
	}bits;
} PMDUInfo_Struct;
extern PMDUInfo_Struct  PMDUInfo;

typedef struct
{
	unsigned int	gain;
	         int	offset;
} tCalibration;
extern tCalibration		calibrFeedA_V1, calibrFeedA_V2, calibrFeedA_V3, calibrFeedA_I1, calibrFeedA_I2, calibrFeedA_I3;
extern tCalibration		calibrFeedB_V1, calibrFeedB_V2, calibrFeedB_V3, calibrFeedB_I1, calibrFeedB_I2, calibrFeedB_I3;

typedef union
{
	unsigned int all;
	struct
	{
		unsigned char POWER_NEGATED 				:1;//L0
		unsigned char OC_THROTTLE_LIMIT 			:1;//L1
		unsigned char LOGIC_ERROR 					:1;//L2
		unsigned char UNKNOWN_FAULT 				:1;//L3
		unsigned char PHASE1_V_OV_FAULT				:1;//L4  	clearFeed1Phase1OV
		unsigned char PHASE1_V_UV_FAULT 			:1;//L5 	clearFeed1Phase1UV
		unsigned char PHASE1_I_OC_FAULT 			:1;//L6 	clearFeed1Phase1OC
		unsigned char PHASE2_V_OV_FAULT				:1;//L7  	clearFeed1Phase2OV

		unsigned char PHASE2_V_UV_FAULT 			:1;//L8  	clearFeed1Phase2UV
		unsigned char PHASE2_I_OC_FAULT  			:1;//L9 	clearFeed1Phase2OC
		unsigned char PHASE3_V_OV_FAULT 			:1;//L10 	clearFeed1Phase3OV
		unsigned char PHASE3_V_UV_FAULT				:1;//L11 	clearFeed1Phase3UV
		unsigned char PHASE3_I_OC_FAULT 			:1;//L12 	clearFeed1Phase3OC
		unsigned char testIO						:1;//L13
		unsigned char rsvd14						:1;//L14
		unsigned char rsvd15						:1;//L15
	}bits;
}FeedAStatus_Struct;
extern FeedAStatus_Struct FeedAPhaseStatus;

typedef union
{
	unsigned int all;
	struct
	{
		unsigned int POWER_NEGATED 					:1;//L0
		unsigned int OC_THROTTLE_LIMIT 				:1;//L1
		unsigned int LOGIC_ERROR 					:1;//L2
		unsigned int UNKNOWN_FAULT 					:1;//L3
		unsigned int PHASE1_V_OV_FAULT				:1;//L4  	clearFeed2Phase1OV
		unsigned int PHASE1_V_UV_FAULT 				:1;//L5 	clearFeed2Phase1UV
		unsigned int PHASE1_I_OC_FAULT 				:1;//L6 	clearFeed2Phase1OC
		unsigned int PHASE2_V_OV_FAULT				:1;//L7  	clearFeed2Phase2OV

		unsigned int PHASE2_V_UV_FAULT 				:1;//L8  	clearFeed2Phase2UV
		unsigned int PHASE2_I_OC_FAULT 				:1;//L9 	clearFeed2Phase2OC
		unsigned int PHASE3_V_OV_FAULT 				:1;//L10 	clearFeed2Phase3OV
		unsigned int PHASE3_V_UV_FAULT				:1;//L11  	clearFeed2Phase3UV
		unsigned int PHASE3_I_OC_FAULT 				:1;//L12 	clearFeed2Phase3OC
		unsigned int testIO							:1;//L13
		unsigned int rsvd14							:1;//L14
		unsigned int rsvd15							:1;//L15
	}bits;
}FeedBStatus_Struct;
extern FeedBStatus_Struct FeedBPhaseStatus;


#endif /* PRU_RPMSG_INTERRUPT0_DUMMY_MAIN_POWER_H_ */
